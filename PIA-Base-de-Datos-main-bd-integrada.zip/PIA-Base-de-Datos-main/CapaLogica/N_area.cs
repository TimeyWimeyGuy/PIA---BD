﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;

namespace CapaLogica
{
    public class N_area
    {
        //INSTANCIA
        private readonly D_area area = new D_area();

        //METODO
        public DataTable MostrarDatos()
        {
            return area.MostrarRegistros();
        }
    }
}
