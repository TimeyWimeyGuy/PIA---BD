﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;

namespace CapaLogica
{
    public class N_tipo
    {
        //INSTANCIA
        private readonly D_tipo tipo = new D_tipo();

        //METODO
        public DataTable MostrarDatos()
        {
            return tipo.MostrarRegistros();
        }
    }
}
