﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;

namespace CapaLogica
{
    public class N_cuartilla
    {
        //INSTANCIA
        private readonly D_cuartilla cuartilla = new D_cuartilla();

        //METODO
        public DataTable MostrarDatos()
        {
            return cuartilla.MostrarRegistros();
        }
    }
}
