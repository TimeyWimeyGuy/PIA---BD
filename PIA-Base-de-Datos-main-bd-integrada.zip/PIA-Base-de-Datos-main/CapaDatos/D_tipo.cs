﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class D_tipo
    {
        //CADENA DE CONEXION
        private readonly SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["conexion"].ConnectionString);

        //METODO
        public DataTable MostrarRegistros()
        {
            DataTable resultado = new DataTable();
            SqlCommand command = new SqlCommand("spmostrar_tipo", connection)
            {
                CommandType = CommandType.StoredProcedure
            };
            connection.Open();

            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            dataAdapter.Fill(resultado);

            return resultado;
        }
    }
}
